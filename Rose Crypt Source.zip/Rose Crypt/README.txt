Rose Crypt - a tool to encrypt/decrypt a file using AES
��
Description
===========
�
Rose Crypt provides users with a simplistic application that can be used
for encrypting files in your computer using a custom passphrase.
�
With its minimal design, Rose Crypt can be used by both advanced and beginner users.
Once the encryption process is finished, you can access the newly created file
from the location you previously selected.
�
Rose Crypt on SourceForge: http://sourceforge.net/projects/rosecrypt
�
�
Reporting bugs
==============
send mail to blade.vp2020@gmail.com
�
�
Copyright
=========
Copyright (c) 2014 ali abdul ghani <blade.vp2020@gm
This Program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software
Foundation, either version 3 of the License, or
(at your option) any later version.
This Program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License along with this library. If not, see <
http://www.gnu.org/�licenses/>.

Note
===========
the files 
dcpblockciphers.pas, dcpcrypt2.pas, dcprijndael.pas, dcpsha256.pas,DCPrijndael.inc, dcpconst.pas, dcpbase64.pas
Taken from
dcpcrypt lib
http://wiki.freepascal.org/DCPcrypt